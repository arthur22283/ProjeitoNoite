package com.arthur.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
// DECLARAÇÃO DA CLASSE IMPLEMENTS COM A ABSTRAÇÃO DA CLASSE SENSOREVENTLISTENER
public class sensorProximidade extends AppCompatActivity implements SensorEventListener {

    //DECLARAÇÃO DAS VARÍAVEIS
    private TextView res;
    private Sensor proximidade;
    private SensorManager medir;
    private Button btnVoltar, btnLuminosidade;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proximidade);

        //MAPEAMENTO DE TODOS OBJETOS DO LAYOUT
        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        res = findViewById(R.id.res);
        btnVoltar = findViewById(R.id.btnVoltar);
        btnLuminosidade = findViewById(R.id.btnLuminosidade);

        btnLuminosidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirLuminosidade();
            }


        });

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

        // CHAMADA DE CALLBACKS QUE TÊM A FUNÇÃO DE DEFINIR O CICLO DE VIDA DAS ACTIVITYS
    }

    @Override
    protected void onResume() {
        medir.registerListener(this, proximidade, SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    @Override
    protected void onPause() {
        medir.unregisterListener(this, proximidade);
        super.onPause();
    }


    public void abrirLuminosidade(){
        Intent janela = new Intent(this, SensorLuminosidade.class);
        startActivity(janela);
    }

   public void abrirVoltar(){
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
   }

    //METÓDO ONSENSORCHANGED QUE OCORRE QUANDO É EXECUTADO OU MODIFICADO ALGUM
    // TIPO DE EVENTO AO SENSOR ESPECÍFICADO
    // SE O VALOR DO EVENTO FOR = 0 ZERO É PORQUE ESTAMOS PRÓXIMOS AO SENSOR, SENÃO ESTÁ AFASTADO

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.values[0] == 0) {

            getWindow().getDecorView().setBackgroundColor(Color.MAGENTA);
            res.setText("PRÓXIMO");

        }else{

            getWindow().getDecorView().setBackgroundColor(Color.CYAN);
            res.setText("AFASTADO");

        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}