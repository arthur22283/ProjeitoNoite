package com.arthur.projetorecuperacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.VideoView;

public class SplashScreen extends AppCompatActivity {

    private MediaPlayer music;
    private VideoView vdi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        //mapeamento do arquivo .mp3 e start na música e do arquivo video

        music = MediaPlayer.create(this, R.raw.music_sc);
        music.start();

        Uri caminho = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.video_sc);
        vdi.setVideoURI(caminho);
        vdi.start();

        //ocultar a barra de ação do android e configurar a activity para tela cheia

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //novo manipulador que controla o metodo postDelayed para abrir a activity num tempo necessitado
        // declaramos o método finish() para destruir a SplashScreeen para impossibilitar o user a usar o voltar no device
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run()
            {
                startActivity(new Intent(getBaseContext(), MainActivity.class));
                finish();
                music.stop();
                vdi.stopPlayback();
            }
    }, 500);
    }
}