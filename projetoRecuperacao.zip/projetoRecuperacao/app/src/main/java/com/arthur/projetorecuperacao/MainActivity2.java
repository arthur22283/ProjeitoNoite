package com.arthur.projetorecuperacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    public Button btnVoltar;
    public TextView RecebeNome, RecebePhone, RecebeEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        RecebeNome = findViewById(R.id.RecebeNome);
        RecebePhone = findViewById(R.id.RecebePhone);
        RecebeEmail = findViewById(R.id.txtEmail);
        btnVoltar = findViewById(R.id.btnVoltar);


        String recebeN = getIntent().getStringExtra("txtNome");
        RecebeNome.setText(recebeN);

        String recebeP = getIntent().getStringExtra("txtPhone");
        RecebePhone.setText(recebeP);

        String recebeE = getIntent().getStringExtra("txtEmail");
        RecebeEmail.setText(recebeE);


        btnVoltar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                abrirVoltar();
            }
        });

    }

    private void abrirVoltar()
    {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }
}

